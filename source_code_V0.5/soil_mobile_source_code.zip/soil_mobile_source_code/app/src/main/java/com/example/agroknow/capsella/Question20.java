//This program is free software: you can redistribute it and/or modify
//        * it under the terms of version 3 of the GNU General Public License as published by
//        * the Free Software Foundation, or (at your option) any later version.
//        *
//        * This program is distributed in the hope that it will be useful,
//        * but WITHOUT ANY WARRANTY; without even the implied warranty of
//        * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//        * GNU General Public License for more details.
//        *
//        * You should have received a copy of the GNU General Public License
//        *License


package com.example.agroknow.capsella;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;


public class Question20 extends Activity {

    private RadioGroup radioGroupQuestion20;
    private RadioButton radioButtonQuestion20;

    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.question20);

        radioGroupQuestion20 = (RadioGroup) findViewById(R.id.radioGroupQ20);
        Button NextButton = (Button) findViewById(R.id.Q20NextButton);
        NextButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (radioGroupQuestion20.getCheckedRadioButtonId() != -1) {

                    int selectedId = radioGroupQuestion20.getCheckedRadioButtonId();
                    radioButtonQuestion20 = (RadioButton) findViewById(selectedId);
                    String AnswerQ20 = radioButtonQuestion20.getText().toString();
                    saveDataToFile(AnswerQ20);
                    saveDataToFile2(AnswerQ20);



                    Intent myIntent = new Intent(view.getContext(), Question21.class);
                    startActivityForResult(myIntent, 0);
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.Mtoast6), Toast.LENGTH_LONG).show();

                }

            }
        });

        Button SkipButton = (Button) findViewById(R.id.Q20SkipButton);
        SkipButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Intent myIntent = new Intent(view.getContext(), Question21.class);
                startActivityForResult(myIntent, 0);
                finish();
            }
        });
    }

    public void saveDataToFile(String answer) {

        try {
            File myFile = new File("/sdcard/SpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile, true);
            OutputStreamWriter myOutWriter =
                    new OutputStreamWriter(fOut);
            myOutWriter.append("  " + "\"roott\":" + " " + "\"" + answer + "\"," + "\n");
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }


    public void saveDataToFile2(String answer) {


        try {
            File myFile = new File("/sdcard/ReviewSpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile, true);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.append("Q:" + getResources().getString(R.string.Q20) + "\n");
            myOutWriter.append("A:" + "\"" + answer + "\"," + "\n");

            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }


    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press back again if you want to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

                                      @Override
                                      public void run() {
                                          doubleBackToExitPressedOnce = false;

                                      }
                                  }

                , 2000);
    }
}

