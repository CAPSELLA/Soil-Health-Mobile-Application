package com.example.agroknow.capsella;


import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class Writer extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.question15);


        saveDataToFile();


        User ob = ((User) getApplicationContext());
        int NumOfLayget = ob.getmGlobalNumOfLay();


        int [] ar = new int[NumOfLayget];

        ar[0] = 5;


        System.out.println(ar.length);
        System.out.println(ar.toString());

        System.out.println(ar[2]);
        System.out.println(ar[8]);



    }



    public void saveDataToFile() {
        User ob = ((User) getApplicationContext());

                     //GPS
        double latget = ob.getmGlobalLat();
        double longet = ob.getmGlobalLon();

                  //NAME & DATE
        String Dateget = ob.getDate();
        String NameTestget = ob.getNameTest();

        //Main Activity Question 1

        String Q1get = ob.getQ1();
        String Q2get = ob.getQ1();
        String Q3get = ob.getQ1();
        String Q4get = ob.getQ1();






        try {
            File myFile = new File("/sdcard/SpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.append("{" + "\n" + "  " + "\"lat\":" + " " + "\"" + latget + "\"," + "\n");
            myOutWriter.append("  " + "\"lon\":" + " " + "\"" + longet + "\"," + "\n");
            myOutWriter.append("  " + "\"name\":" + " " + "\"" + NameTestget + "\"," + "\n" );
            myOutWriter.append("  " + "\"date\":" + " " + "\"" + Dateget + "\"," + "\n");
            myOutWriter.append("  " + "\"fcov\":" + " " + "\""+Q1get+"\"," + "\n" );
            myOutWriter.append("  " + "\"fslo\":" + " " + "\""+Q2get+"\"," + "\n" );
            myOutWriter.append("  " + "\"pcov\":" + " " + "\""+Q3get+"\"," + "\n" );
            myOutWriter.append("  " + "\"leg\":" + " " + "\""+Q4get+"\"," + "\n" );



            myOutWriter.close();
            fOut.close();


        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }


    }
}
