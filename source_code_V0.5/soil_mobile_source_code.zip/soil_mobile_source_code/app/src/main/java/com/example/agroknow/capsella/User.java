package com.example.agroknow.capsella;

import android.app.Application;


public class User extends Application {

    private String mGlobaltoken;
    private String mGlobalBuffer;
    private String mGlobalUrl;
    private String mGlobalfullName;
    private int mGlobalCODE;
    private int mGlobalNumOfLay;
    private double mGlobalLat;
    private double mGlobalLon;
    private String Date;
    private String Name;
    private String Q1;
    private String Q2;
    private String Q3;
    private String Q4;
    private String Q5;




    private int [] ar ;


    /* SAVE DATA */

    public int [] getArray() {

        return ar;
    }

    public void setArray(int [] str) {

        ar = str;

    }


    /* GPS CLASS */
    public String getDate() {

        return Date;
    }

    public void setDate(String str) {

        Date = str;

    }

        /* UserInformation CLASS */


    public String getNameTest() {

        return Name;
    }

    public void setNameTest(String str) {

        Name = str;

    }

            /* Main Activity CLASS */

    public String getQ1() {

        return Q1;
    }

    public void setQ1(String str) {

        Q1 = str;

    }

            /* Q2 CLASS */

    public String getQ2() {

        return Q2;
    }

    public void setQ2(String str) {

        Q2 = str;

    }
            /* Q3 CLASS */


    public String getQ3() {

        return Q3;
    }

    public void setQ3(String str) {

        Q3 = str;

    }

                /* Q4 CLASS */


    public String getQ4() {

        return Q4;
    }

    public void setQ4(String str) {

        Q4 = str;

    }



    public String getQ5() {

        return Q5;
    }

    public void setQ5(String str) {

        Q5 = str;

    }
































    public String getGlobalVarValue() {
        return mGlobaltoken;
    }

    public void setGlobalVarValue(String str) {

        mGlobaltoken = str;

    }


    public String getGlobalVarValue2() {

        return mGlobalBuffer;
    }


    public void setGlobalVarValue2(String str2) {

        mGlobalBuffer = str2;

    }


    public String getGlobalVarValueUrl() {

        return mGlobalUrl;
    }

    public void setGlobalVarValueUrl(String str3) {

        mGlobalUrl = str3;
    }


    public String getGlobalfullName() {

        return mGlobalfullName;
    }

    public void setGlobalfullName(String str4) {

        mGlobalfullName = str4;
    }


    public int getGlobalCODE() {

        return mGlobalCODE;
    }

    public void setGlobalCODE(int str5) {

        mGlobalCODE = str5;
    }


    public int getmGlobalNumOfLay() {

        return mGlobalNumOfLay;
    }

    public void setmGlobalNumOfLay(int str6) {

        mGlobalNumOfLay = str6;
    }


    public double getmGlobalLat() {

        return mGlobalLat;

    }

    public void setmGlobalLat(double str7) {

        mGlobalLat = str7;
    }


    public double getmGlobalLon() {

        return mGlobalLon;

    }

    public void setmGlobalLon(double str8) {

        mGlobalLon = str8;
    }


}
