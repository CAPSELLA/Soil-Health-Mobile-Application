//This program is free software: you can redistribute it and/or modify
//        * it under the terms of version 3 of the GNU General Public License as published by
//        * the Free Software Foundation, or (at your option) any later version.
//        *
//        * This program is distributed in the hope that it will be useful,
//        * but WITHOUT ANY WARRANTY; without even the implied warranty of
//        * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//        * GNU General Public License for more details.
//        *
//        * You should have received a copy of the GNU General Public License
//        *License




package com.example.agroknow.capsella;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;



public class Question10 extends Activity {
    int i = -1;

    SeekBar sb;
    TextView valuetxt;
    TextView laynumID;


    public void onCreate(Bundle savedInstanceState) {


        User ob = ((User) getApplicationContext());
        final int NumOfLayget = ob.getmGlobalNumOfLay();
        if (Language_Choose.flagG == false) {
            saveDataToFile3();
            saveDataToFile5();

            Language_Choose.flagG = true;
        }

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question10);


        laynumID = (TextView) findViewById(R.id.textView5);
        laynumID.setText(getResources().getString(R.string.LayerNumberID) + " " + String.valueOf(Language_Choose.countID));
        Language_Choose.countID = Language_Choose.countID + 1;

        sb = (SeekBar) findViewById(R.id.seekBar);
        valuetxt = (TextView) findViewById(R.id.textView10);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                valuetxt.setText(String.valueOf(progress));

            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {

            }
        });



        Button NextButton = (Button) findViewById(R.id.Q10NextButton);
        NextButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {






                if (NumOfLayget != Language_Choose.counterLay) {


                    if (valuetxt.getText().toString().length() != 0) {
                        String IntegerCheck = valuetxt.getText().toString();
                        try {
                            Integer.parseInt(IntegerCheck);
                            int NumberOfLayers = Integer.parseInt(String.valueOf(valuetxt.getText()));

                            if (NumOfLayget != Language_Choose.counterLay) {

                                saveDataToFile(NumberOfLayers);
                                saveDataToFile6(NumberOfLayers);

                                Language_Choose.counterLay = Language_Choose.counterLay + 1;

                            }
                            Intent myIntent = new Intent(view.getContext(), Question10.class);
                            startActivityForResult(myIntent, 0);
                            finish();
                        } catch (NumberFormatException e) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.Mtoast), Toast.LENGTH_SHORT).show();

                        }
                    } else {
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.Mtoast2), Toast.LENGTH_SHORT).show();

                    }

                }else {
                    if (valuetxt.getText().toString().length() != 0) {


                        int NumberOfLayers = Integer.parseInt(String.valueOf(valuetxt.getText()));
                        saveDataToFile2(NumberOfLayers);
                        saveDataToFile6(NumberOfLayers);

                        Language_Choose.counterLay = 1;
                        Language_Choose.countID = 1;
                        Language_Choose.flagG = false;

                        Intent myIntent = new Intent(view.getContext(), Question11.class);
                        startActivityForResult(myIntent, 0);
                        finish();

                    }
                    else{
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.Mtoast2), Toast.LENGTH_SHORT).show();

                    }
                }


            }
        });


    }


    public void saveDataToFile(int answer) {

        try {
            File myFile = new File("/sdcard/SpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile,true);
            OutputStreamWriter myOutWriter =
                    new OutputStreamWriter(fOut);
            myOutWriter.append("    " +answer+"," + "\n");
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }


    public void saveDataToFile2(int answer) {
        try {
            File myFile = new File("/sdcard/SpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile,true);
            OutputStreamWriter myOutWriter =
                    new OutputStreamWriter(fOut);
            myOutWriter.append("    " +answer+ "\n" + "   " + "]," + "\n");
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }



    public void saveDataToFile3() {

        try {
            File myFile = new File("/sdcard/SpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile,true);
            OutputStreamWriter myOutWriter =
                    new OutputStreamWriter(fOut);
            myOutWriter.append("  " + "\"agdim\""+ ": [" + "\n");
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }


    public void saveDataToFile5() {


        try {
            File myFile = new File("/sdcard/ReviewSpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile, true);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.append("Q:" + getResources().getString(R.string.Q10) + "\n");
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }


    }

    public void saveDataToFile6(int answer) {


        try {
            File myFile = new File("/sdcard/ReviewSpadeTest.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile, true);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.append("A:" + "\"" + answer + "\"," + "\n");

            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }


    }

    boolean doubleBackToExitPressedOnce = false;
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press back again if you want to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

                                      @Override
                                      public void run() {
                                          doubleBackToExitPressedOnce=false;

                                      }
                                  }

                , 2000);
    }

}
